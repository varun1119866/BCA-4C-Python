#main.py
from prime import prime_function
print("Name: Dhruv\nRoll No: 2210997071")
a = int(input("Enter a number: "))
prime_function(a)