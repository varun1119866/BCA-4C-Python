import math
print("Name: Dhruv\nRoll No: 2210997071")
Raw_List=[i for i in range(1,11)]
Squares_List=[x**2 for x in Raw_List]
Factorial_List=[math.factorial(x)for x in Raw_List]
print("Raw_List:",Raw_List)
print("Squares_List:",Squares_List)
print("Factorial_List:",Factorial_List)
