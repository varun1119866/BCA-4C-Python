mydict={'name':'manoj','age':'30','phone':'5478965853','state':'punjab'}
print("====================================================================")
print('{:<15}\t||\t {:<15}'.format('key','value'))
print("====================================================================")
for key,value in mydict .items():
    print('{:<15}\t||\t {:<15}'.format(key,value))
print("====================================================================")
print('total records:',len(mydict))